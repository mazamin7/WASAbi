libfreetype-dll
===============

Compiled versions of [freetype][freetype] for Windows 32bit and 64bit.

Compiled with MS Visual Studio 2013.

Other sources
-------------

You can also use the version provided by [GTK+][gtkp]. Click the link for either
[32bit][32bit] or [64bit][64bit] Windows downloads, scroll down to _Required
third party dependencies_, download the Freetype Run-time archive and extract
it. The archive will have the `libfreetype-6.dll` in `bin/`.

[freetype]: http://www.freetype.org/
[gtkp]: http://www.gtk.org/download/
[32bit]: http://www.gtk.org/download/win32.php
[64bit]: http://www.gtk.org/download/win64.php